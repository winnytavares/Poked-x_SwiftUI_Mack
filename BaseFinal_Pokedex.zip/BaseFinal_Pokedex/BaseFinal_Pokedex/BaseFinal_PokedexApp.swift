//
//  BaseFinal_PokedexApp.swift
//  BaseFinal_Pokedex
//
//  Created by Artur Ferreira on 31/07/25.
//

import SwiftUI

@main
struct BaseFinal_PokedexApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//import SwiftUI
//
//struct Pokemon {
//    var id: Int
//    var name: String
//    var types: [ElementType]{
//        TabView {
//            ZStack {
//                
//                Spacer(minLength: 30)
//                
//                VStack() {
//                    VStack {
//                        Button {
//                            print("a")
//                        } label: {
//                            Image(systemName: "lessthan")
//                            Text("Suporte")
//                        }
//                    }
//                    
//                    Spacer(minLength: 30)
//                    VStack {
//                        Image(systemName: "iphone.smartbatterycase.gen2")
//                        Text("Pokedex")
//                        Text("Lista de pokemons para conquista")
//                        AsyncImage(url: URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png")) {
//                            image in
//                            image.image
//                        }
//          
//                        
//                    }
//                    
//    
//            .tabItem { Label("Pokedex", systemImage: "book.fill") }
//            Text("Tab Content 2")
//                .tabItem { Label("estatísticas", systemImage: "chart") }
//    
//        }
//    }
//}
//
//
//struct Poke_Previews: PreviewProvider {
//    static var previews: some View {
//        Pokemon()
//    }
//}
//
//
//

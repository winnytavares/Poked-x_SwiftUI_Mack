////
//import SwiftUI
//
//struct Pokemon {
//    var id: Int
//    var name: String
//    var data: [ToyShape] = [
//        .init(type: "Cube", count: 5),
//        .init(type: "Sphere", count: 4),
//        .init(type: "Pyramid", count: 4)
//    ]
//    var types: [ElementType]{
//
//            ZStack {
//                
//                Spacer(minLength: 30)
//                
//                VStack() {
//                    VStack {
//                        Button {
//                            print("a")
//                        } label: {
//                            Image(systemName: "lessthan")
//                            Text("Suporte")
//                        }
//                    }
//                    
//                    Spacer(minLength: 30)
//                    VStack {
//                        Image(systemName: "iphone.smartbatterycase.gen2")
//                        Text("Pokedex")
//                        Text("Lista de pokemons para conquista")
//                        AsyncImage(url: URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png")) {
//                            image in
//                            image.image
//                        }
//
//
//                        
//                        
//                    }
//                    
//                    .tabItem { Label("Pokedex", systemImage: "book.fill") }
//                    Text("Tab Content 2")
//                        .tabItem { Label("estatísticas", systemImage: "chart") }
//                    
//                }
//            }
//        }
//    }
//}
//
//
//struct Poke_Previews: PreviewProvider {
//    static var previews: some View {
//        Pokemon(id: 1, name: "name")
//    }
//}
//
//struct ToyShape: Identifiable {
//    var type: String
//    var count: Double
//    var id = UUID()
//}

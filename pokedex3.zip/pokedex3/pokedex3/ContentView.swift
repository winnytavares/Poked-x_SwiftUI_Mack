//
//  ContentView.swift
//  pokedex3
//
//  Created by Aluno Mack on 31/07/25.
//

import SwiftUI
import Charts


struct BarChart: View {
    
    var data: [ToyShape] = [
        .init(type: "Zaroark", count: 5),
        .init(type: "Spinda", count: 7),
        .init(type: "Aromatisse", count: 8),
        .init(type: "Zorua", count: 3),
        .init(type: "Basculegion", count: 3),
    ]
    var data2: [ToyShape] = [
        .init(type: "Grass", count: 5),
        .init(type: "Eletric", count: 7),
        .init(type: "Fire", count: 8),
        .init(type: "Flying", count: 3),
        .init(type: "Dragon", count: 3),
        .init(type: "Water", count: 3),
    ]

    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.red
                VStack(spacing: 20) {
                    GroupBox("Pokemons Lendários coletados") {
                        Chart {
                            BarMark(
                                x: .value("Shape Type", data[0].type),
                                y: .value("Total Count", data[0].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[1].type),
                                y: .value("Total Count", data[1].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[2].type),
                                y: .value("Total Count", data[2].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[3].type),
                                y: .value("Total Count", data[3].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[4].type),
                                y: .value("Total Count", data[4].count)
                            )
                            
                        }
                        .frame(height: 200)
                        .bold()
                    }
                    
                    GroupBox("Tipos de Pokemons coletados") {
                        Chart {
                            BarMark(
                                x: .value("Shape Type", data[0].type),
                                y: .value("Total Count", data[0].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[1].type),
                                y: .value("Total Count", data[1].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[2].type),
                                y: .value("Total Count", data[2].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[3].type),
                                y: .value("Total Count", data[3].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[4].type),
                                y: .value("Total Count", data[4].count)
                            )
                            BarMark(
                                x: .value("Shape Type", data[5].type),
                                y: .value("Total Count", data[5].count)
                            )
                            
                        }
                        .frame(height: 200)
                    }
                    //            .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
            .background(Color.red.ignoresSafeArea())
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Text("exemplo")
                }
            }
        }
    }
}

struct BarChart_PreviewProvider: PreviewProvider {
    static var previews: some View {
        BarChart()
    }
}
    


    struct ToyShape: Identifiable {
        var type: String
        var count: Double
        var id = UUID()
    }

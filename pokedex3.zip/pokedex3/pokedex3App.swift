//
//  pokedex3App.swift
//  pokedex3
//
//  Created by Aluno Mack on 31/07/25.
//

import SwiftUI

@main
struct pokedex3App: App {
    var body: some Scene {
        WindowGroup {
            BarChart()
        }
    }
}
